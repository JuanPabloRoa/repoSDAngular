angular.module('angularSpa')
    .service('isapresService', function($http, $rootScope){
        
       var urlBase='http://localhost:8000/api/';

        this.getIsapres = function(){
            return $http.get(urlBase + 'isapres');
        };


        this.getIsapreEspecifica = function(idIsapre){
            return $http.get(urlBase + 'isapre/'+idIsapre);
        };



    });
