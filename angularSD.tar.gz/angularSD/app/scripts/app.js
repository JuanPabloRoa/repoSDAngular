(function(){

    angular.module('angularSpa', [
    'ngRoute'
    ])
    

    .config(function($routeProvider){
        $routeProvider

        .when('/home', {
            templateUrl: 'views/main.html',
        
        })

        
        .when('/isapres', {
            templateUrl:'views/verIsapres.html',
            controller:'IsapresCtrl'})

        .when('/afps', {
            templateUrl:'views/verAfps.html',
            controller:'AfpsCtrl'})



        .otherwise({
            redirectTo: '/home'
          });
    });//fin enrutaciones

})();
