angular.module('angularSpa')
.controller('IsapresCtrl', function($scope, $location, $rootScope, $routeParams, isapresService){
    //Se define SIEMPRE un controlador por entidad/funcionalidad...





///obtener Isapres

$scope.listaIsapres={};
function getIsapres(){
        isapresService.getIsapres()
        .success(function(data){
            console.log(data);
            $scope.isapres=data;


for ( i =0; i <$scope.isapres.length; i++) {
            
$scope.listaIsapres[i]={clasificacion:$scope.isapres[i].nombre,valor:$scope.isapres[i].id};
            };})
         .error(function(error){
            $scope.status = 'Error al consultar por isapres';
        });

    };

    getIsapres();
/////


////obtener reclamos especificos



$scope.reclamosEspecifico;

$scope.getReclamosEspecifico=function getReclamosEspecifico(){
idIsapre=$scope.IsapreEscogida.valor;

        isapresService.getIsapreEspecifica(idIsapre)
        .success(function(data){
         
            $scope.reclamosEspecifico = data.reclamos;
             console.log($scope.reclamosEspecifico);


        })
        .error(function(error){
            $scope.status = 'Error al consultar por reclamos especificos';
        });
    };

///////


});
