angular.module('angularSpa')
.controller('AfpsCtrl', function($scope, $rootScope, $routeParams,$filter,$location, afpsService){



///obtener afps

$scope.listaAfps={};
function getAfps(){
        afpsService.getAfps()
        .success(function(data){
            console.log(data);
            $scope.afps=data;


for ( i =0; i <$scope.afps.length; i++) {
            
$scope.listaAfps[i]={clasificacion:$scope.afps[i].nombre,valor:$scope.afps[i].id};
console.log(i);
            };})
         .error(function(error){
            $scope.status = 'Error al consultar por afps';
        });

    };

    getAfps();
/////


////obtener reclamos especificos



$scope.reclamosEspecifico;

$scope.getReclamosEspecifico=function getReclamosEspecifico(){
idAFP=$scope.AfpEscogida.valor;

        afpsService.getAfpEspecifica(idAFP)
        .success(function(data){
         
            $scope.reclamosEspecifico = data.reclamos;
             console.log($scope.reclamosEspecifico);


        })
        .error(function(error){
            $scope.status = 'Error al consultar por reclamos especificos';
        });
    };









///////

});
