angular.module('angularSpa')
    .service('afpsService', function($http){
      //Un servicio es la forma de comunicarse con el exterior.
        
        var urlBase='http://localhost:8000/api/';

        this.getAfps = function(){
            return $http.get(urlBase + 'afps');
        };


        this.getAfpEspecifica = function(idAFP){
            return $http.get(urlBase + 'afp/'+idAFP);
        };




    });
