<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});


Route::middleware('cors')->group(function (){
	Route::get('/afps', 'AfpController@index');
	Route::get('/afp/{id}', 'AfpController@show');

	Route::get('/isapres', 'IsapreController@index');
	Route::get('/isapre/{id}', 'IsapreController@show');

	Route::get('/reclamos', 'ReclamosController@index');
	Route::get('/reclamo/{id}', 'ReclamosController@show');

	Route::get('/afp/{id}/categoria/{cat_id}','CategoryController@afp_cat');
	Route::get('/isapre/{id}/categoria/{cat_id}','CategoryController@isapre_cat');

});