<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\afp;
use Illuminate\Support\Facades\Cache;

class AfpController extends Controller
{
    //
    public function index()
    {
    	return afp::with('reclamos')->get();
    }

    /*public function store(Request $request)
    {
    	$afp = new afp::(Request::all());
    	$afp->save();
    	return $afp();
    }*/

    public function show($id)
    {
        if(Cache::store('memcached')->get('afp'.$id) != null){
            return Cache::get('afp'.$id);    
        }

        Cache::store('memcached')->put('afp'.$id, afp::with('reclamos')->findOrFail($id),1);
    	
        return afp::with('reclamos')->findOrFail($id);
    }

    public function destroy($id)
    {
    	$afp = afp::find($id);
    	$afp->delete();
    }
}
