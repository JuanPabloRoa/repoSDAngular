<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\category;
use App\reclamo;
use App\afp;

class CategoryController extends Controller
{
    //
    public function index()
    {
    	return category::all();
    }

    /*public function store()
    {
    	$isapre = new isapre::(Request::all());
    	$isapre->save();
    	return $isapre();
    }*/

    public function show($id)
    {
    	return category::find($id);
    }

    public function destroy($id)
    {
    	$category = category::find($id);
    	$category->delete();
    }

    public function afp_cat($id, $cat_id)
    {
    	$category = category::where('id',$cat_id)->first();
    	$reclamos = $category->reclamos()->where('afp_id', $id)->get();
    	#dd($reclamos);
    	return $reclamos;
    }

    public function isapre_cat($id, $cat_id)
    {
    	$category = category::where('id',$cat_id)->first();
        $reclamos = $category->reclamos()->where('isapre_id', $id)->get();
        #dd($reclamos);
        return $reclamos;
    }
}
