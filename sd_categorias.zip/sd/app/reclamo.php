<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class reclamo extends Model
{
    //
   protected $fillable = ['reclamo', 'afp_id', 'isare_id', 'fuente'];

   public function afp()
   {
   		return $this->belongsTo('App\afp');
   }

   public function isapre()
   {
   		return $this->belongsTo('App\isapre');
   }

   public function categories()
   {
      return $this->belongsToMany('App\category', 'cat_rec', 'rec_id', 'cat_id');
   }
}
