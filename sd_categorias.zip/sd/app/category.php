<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class category extends Model
{
    //
	protected $fillable = ['name'];

    public function reclamos()
    {
    	return $this->belongsToMany('App\reclamo', 'cat_rec', 'cat_id', 'rec_id');
    }
}
