<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\isapre;

class IsapreController extends Controller
{
    //
    public function index()
    {
    	return isapre::with('reclamos')->get();
    }

    /*public function store()
    {
    	$isapre = new isapre::(Request::all());
    	$isapre->save();
    	return $isapre();
    }*/

    public function show($id)
    {
    	return isapre::with('reclamos')->findOrFail($id);
    }

    public function destroy($id)
    {
    	$isapre = isapre::find($id);
    	$isapre->delete();
    }
}
