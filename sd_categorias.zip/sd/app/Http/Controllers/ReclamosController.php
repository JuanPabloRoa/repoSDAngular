<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\reclamo;

class ReclamosController extends Controller
{
    //
    public function index()
    {
    	return reclamo::all();
    }

    /*public function store()
    {
    	$reclamo = new reclamo(Request::all());
    	$reclamo->save();
    	return $reclamo;
    }*/

    public function show($id)
    {
    	$reclamo = reclamo::find($id);
    	return $reclamo;
    }

    public function destroy($id)
    {
    	$reclamo = reclamo::find($id);
    	$reclamo->delete();
    }
}
