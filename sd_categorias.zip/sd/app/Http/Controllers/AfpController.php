<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\afp;

class AfpController extends Controller
{
    //
    public function index()
    {
    	return afp::with('reclamos')->get();
    }

    /*public function store(Request $request)
    {
    	$afp = new afp::(Request::all());
    	$afp->save();
    	return $afp();
    }*/

    public function show($id)
    {
    	return afp::with('reclamos')->findOrFail($id);
    }

    public function destroy($id)
    {
    	$afp = afp::find($id);
    	$afp->delete();
    }
}
