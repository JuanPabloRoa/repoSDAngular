<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class afp extends Model
{
    //
	protected $fillable = ['nombre'];

    public function reclamos()
    {
    	return $this->hasMany('App\reclamo');
    }
}
