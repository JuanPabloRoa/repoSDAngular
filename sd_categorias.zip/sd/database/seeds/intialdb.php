<?php

use Illuminate\Database\Seeder;
use App\afp;
use App\isapre;
use App\reclamo;
use App\category;


class intialdb extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $afp1 = new afp();
        $afp1->nombre = 'Modelo';
        $afp1->save();

        $afp2 = new afp();
        $afp2->nombre = 'Vital';
        $afp2->save();

        $isapre1 = new isapre();
        $isapre1->nombre = 'Consalud';
        $isapre1->save();
    	
    	$isapre2 = new isapre();
        $isapre2->nombre = 'Banmedica';
        $isapre2->save();

        $reclamo1 = new reclamo();
        $reclamo1->afp_id = 1;
        $reclamo1->reclamo = 'vale popó';
        $reclamo1->fuente = 'www.reclamos.cl';
        $reclamo1->save();

        $reclamo2 = new reclamo();
        $reclamo2->afp_id = 2;
        $reclamo2->reclamo = 'vale mega popó';
        $reclamo2->fuente = 'www.reclamos.cl';
        $reclamo2->save();


        $reclamo3 = new reclamo();
        $reclamo3->isapre_id = 1;
        $reclamo3->reclamo = 'vale isapre mega popó';
        $reclamo3->fuente = 'www.reclamos.cl';
        $reclamo3->save();

        $reclamo4 = new reclamo();
        $reclamo4->isapre_id = 2;
        $reclamo4->reclamo = 'vale isapre popó';
        $reclamo4->fuente = 'www.reclamos.cl';
        $reclamo4->save();

        $categoria = new category();
        $categoria->name = 'Servicios Generales';
        $categoria->save();

        $categoria2 = new category();
        $categoria2->name = 'Prestaciones';
        $categoria2->save();

        $categoria3 = new category();
        $categoria3->name = 'Atención de Usuarios';
        $categoria3->save();

        $categoria4 = new category();
        $categoria4->name = 'Precio';
        $categoria4->save();

        $categoria5 = new category();
        $categoria5->name = 'Calidad de Servicio';
        $categoria5->save();

        $reclamo1->categories()->attach($categoria);
        $reclamo1->categories()->attach($categoria2);
        $reclamo1->categories()->attach($categoria5);

        $reclamo2->categories()->attach($categoria2);
        $reclamo2->categories()->attach($categoria4);

        $reclamo3->categories()->attach($categoria4);
        $reclamo3->categories()->attach($categoria5);
        $reclamo3->categories()->attach($categoria3);

        $reclamo4->categories()->attach($categoria2);
        $reclamo4->categories()->attach($categoria3);

    }
}
